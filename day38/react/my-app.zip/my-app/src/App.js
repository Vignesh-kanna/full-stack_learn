import './App.css';
import GetPost from './Component/GetPost';

function App() {
  return (
    <div className="App">
      <GetPost/>
    </div>
  );
}

export default App;
