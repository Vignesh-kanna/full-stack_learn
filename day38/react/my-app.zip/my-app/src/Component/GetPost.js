import React, { useEffect, useState } from 'react';
import axios from 'axios';

const GetPost = () => {
    const [posts, setPosts] = useState([]);
    useEffect(() => {
        axios.get('http://localhost:3001/posts')
            .then(response => setPosts(response.data))
            .catch(err => console.log(err));
    }, []);
    return (
        <div>
            <h2>GetPost</h2>
            <hr />
            <ul>
                {posts.map(puser =>
                    <li key={puser.id}>{puser.title} - {puser.views}</li>
                )}
            </ul>
        </div>
    );
};

export default GetPost;