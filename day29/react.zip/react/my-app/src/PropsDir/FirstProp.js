import React from 'react'

const FirstProp = (props) => {
  return (
    <div>
      FirstProp : {props.name}
    </div>
  )
}

export default FirstProp
