import React from 'react'

const HeaderComponent = () => {
  return (
    <div>
        <header className="App-header">
            <h1>Welcome to My React App</h1>
            <p>This is a simple header component.</p>
        </header>
    </div>
  )
}

export default HeaderComponent
